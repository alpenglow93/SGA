#include "MainGame.h"

void main()
{
	MainGame mg;
	mg.Update();
}