#include <iostream>
#include <time.h>
using namespace std;

//����
//��������

void main()
{
	srand(time(NULL));

	int puzzleNum[5][5];
	int inputNum;
	int inputCount = 0;
	int number = 1;
	bool congratulation = false;

	//������ �ʱ�ȭ
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{
			puzzleNum[i][j] = number;
			number++;
		}
	}
	puzzleNum[4][4] = 0;	//25�� ����ִ� [4][4] ��ġ�� 0���� �����

	//���� �˰�����
	for(int i = 0; i < 100; i++)
	{
		int dest1 = rand() % 5;
		int dest2 = rand() % 5;
		int sour1 = rand() % 5;
		int sour2 = rand() % 5;
		int temp;

		temp = puzzleNum[dest1][sour1];
		puzzleNum[dest1][sour1] = puzzleNum[dest1][sour2];
		puzzleNum[dest1][sour2] = puzzleNum[dest2][sour1];
		puzzleNum[dest2][sour1] = puzzleNum[dest2][sour2];
		puzzleNum[dest2][sour2] = temp;
	}

	//Zero �� ��ġ�� ã�ƺ��� [4][4]�� ������ 0�� ���� ��ġ�� ����
	int rememberA, rememberB;
	if(puzzleNum[4][4] != 0)
	{
		for(int i = 0; i < 5; i++)
		{
			for(int j = 0; j < 5; j++)
			{
				if(puzzleNum[i][j] == 0)
				{
					rememberA = i;
					rememberB = j;
					int temp = puzzleNum[4][4];
					puzzleNum[4][4] = puzzleNum[i][j];
					puzzleNum[i][j] = temp;
				}
			}
		}
	}

	//���ӽ���
	while(1)
	{
		for(int i = 0; i < 5; i++)
		{
			for(int j = 0; j < 5; j++)
			{
				if(puzzleNum[i][j] == 0)
				{
					cout << "��" << "\t";
				}
				else
				{
					cout << puzzleNum[i][j] << "\t";
				}
			}
			cout << endl << endl;
		}
		int checkNumber = 1;
		int checkCount = 0;
		if(!congratulation)
		{
			for(int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 5; j++)
				{
					if(puzzleNum[i][j] == checkNumber)
					{
						checkNumber++;
						checkCount++;
					}
				}
			}
		}
		else break;

		cout << "���� Input Count: " << inputCount << endl;
		cout << "������ ������ ���ڸ� �Է��ϼ���." << endl;
		cin >> inputNum;

		while(1)
		{
			if(!cin.good() || inputNum != 8 && inputNum != 6 && inputNum != 2 && inputNum != 4)
			{
				cin.clear();
				cin.ignore(INT_MAX, '\n');
				cout << "�ٽ� �Է��ϼ���." << endl;
				cin >> inputNum;
				cout << endl;
				continue;
			}
			else break;
		}

		if(inputNum == 4)
		{
			for(int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 5; j++)
				{
					if(puzzleNum[i][j] == 0 && j > 0)
					{
						int temp = puzzleNum[i][j];
						puzzleNum[i][j] = puzzleNum[i][j - 1];
						puzzleNum[i][j - 1] = temp;
					}
				}
			}
		}
		if(inputNum == 8)
		{
			for(int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 5; j++)
				{
					if(puzzleNum[i][j] == 0 && j > 0)
					{
						int temp = puzzleNum[i][j];
						puzzleNum[i][j] = puzzleNum[i - 1][j];
						puzzleNum[i - 1][j] = temp;
					}
				}
			}
		}
		if(inputNum == 6)
		{
			for(int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 5; j++)
				{
					if(puzzleNum[i][j] == 0 && j > 0)
					{
						int temp = puzzleNum[i][j];
						puzzleNum[i][j] = puzzleNum[i][j + 1];
						puzzleNum[i][j + 1] = temp;
					}
				}
			}
		}
		if(inputNum == 2)
		{
			for(int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 5; j++)
				{
					if(puzzleNum[i][j] == 0 && j > 0)
					{
						int temp = puzzleNum[i][j];
						puzzleNum[i][j] = puzzleNum[i + 1][j];
						puzzleNum[i + 1][j] = temp;
					}
				}
			}
		}

		system("cls");
		inputCount++;
	}
	
}